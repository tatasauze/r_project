function siddisp(cad)
%
global SIDOPTION;

if SIDOPTION(6) == 0
   disp(cad);
end